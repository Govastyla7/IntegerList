public interface IntegerList {


    int getLength();

    int insertLast(int value);

    int getFirst();

    int deleteFirst();

    boolean search(int value);

    void print();

}
